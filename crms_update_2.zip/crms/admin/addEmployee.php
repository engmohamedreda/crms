<?php 

	ob_start();
	require_once('../includes.php');
	
	$admin = new admin();
	
	if(!$admin->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $admin->data();
	
	if(!$admin->getAdmin($id)){
		
		header('location: ../');
		
	}
	
	$data  = $admin->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['name'];
		$email = $singleData['email'];
		$id    = $singleData['id'];
	
	}
					
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $name ?></title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/datepicker3.css" rel="stylesheet">
<link href="../assets/css/styles.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="../assets/css/fa.css" rel="stylesheet">

<!--Icons-->
<script src="../assets/js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="../assets/js/html5shiv.js"></script>
<script src="../assets/js/respond.min.js"></script>
<![endif]-->

<script>

	function checke(email){
	
	  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	  
	  if(!re.test(email)){
		  
		  alert("this is not a valid email");
		  
	  }

	}

	function checkp(phone){
	 
		if(isNaN(phone) || phone.length != 10) { 
			alert("this is not a valid phone");  
			return false;  
        } 
		
	}

</script>

</head>

<body>
	
	<?php 
	
		include_once('parts/header.php');
		
	?>
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="./"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Add Employee</li>
			</ol>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Add Employee</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="col-md-10">
					<?php 
						if(isset($_POST['submit'])){
							
							$ssn = $_POST['ssn'];
							$name = $_POST['name'];
							$email = $_POST['email'];
							$password = $_POST['password'];
							$confirm = $_POST['confirm'];
							$phone = $_POST['phone'];
							
							$employee = new employee();
							
							if($employee->add($ssn,$name,$email,$phone,$password,$confirm,$id)){
								echo'<div class="alert bg-success" role="alert">
										<svg class="glyph stroked checkmark">
											<use xlink:href="#stroked-checkmark"></use>
										</svg>
										successful add
									</div>';
							}else{
								echo'<div class="alert bg-danger" role="alert">
										'.$employee->message().'
									</div>';
							}
							
						}
					?>
					<form role="form" method="post" enctype="multipart/form-data">
						
						<div class="form-group">
							<label>employee ssn</label>
							<input class="form-control" name="ssn">
						</div>
						<div class="form-group">
							<label>employee name</label>
							<input class="form-control" name="name">
						</div>
						<div class="form-group">
							<label>employee email</label>
							<input class="form-control" name="email" onChange="checke(this.value)" type="email">
						</div>
						<div class="form-group">
							<label>employee phone</label>
							<input type="text" class="form-control" onChange="checkp(this.value)" name="phone">
						</div>
						<div class="form-group">
							<label>employee password</label>
							<input class="form-control" name="password" type="password">
						</div>	
						<div class="form-group">
							<label>confirm password</label>
							<input class="form-control" name="confirm" type="password">
						</div>	
						
						<div class="form-group">
							<button type="submit" name="submit" class="btn btn-primary">Save</button>
							<button type="reset" class="btn btn-default">Reset</button>
						</div>
						<br><br>
					</form>
				</div>
			</div>
		</div>
		
	</div>

	<script src="../assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/chart.min.js"></script>
	<script src="../assets/js/chart-data.js"></script>
	<script src="../assets/js/easypiechart.js"></script>
	<script src="../assets/js/easypiechart-data.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
