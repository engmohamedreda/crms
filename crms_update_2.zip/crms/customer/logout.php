<?php 

	ob_start();
	require_once('../includes.php');
	
	$customer = new customer();
	
	if(!$customer->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $customer->data();
	
	if(!$customer->get($id)){
		
		header('location: ../');
		
	}
	
	$data  = $customer->data();
	
	$customer->logout();
	
	header('location: ../');
	
					
?>

