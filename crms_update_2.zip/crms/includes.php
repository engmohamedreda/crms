<?php 

// call all php classes

require_once('php/class_system.php');
require_once('php/class_db_query.php');
require_once('php/class_admin.php');
require_once('php/class_employee.php');
require_once('php/class_access.php');
require_once('php/class_car.php');
require_once('php/class_customer.php');
require_once('php/class_booking.php');
require_once('php/mailto.php');