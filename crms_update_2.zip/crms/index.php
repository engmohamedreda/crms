<?php 

	ob_start();
	require_once('includes.php');
	
	$admin = new admin();
	$emplo = new employee();
	$customer = new customer();
	
						
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Al geleses For Online CarRenting</title>

<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/datepicker3.css" rel="stylesheet">
<link href="assets/css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="assets/js/html5shiv.js"></script>
<script src="assets/js/respond.min.js"></script>
<![endif]-->

<script src="js/jquery-1.11.3.min.js"></script>
<script>
$(function(){
	var dataArray=new Array();
	dataArray[0]="body1";
	dataArray[1]="body2";
	dataArray[2]="body3";

	var thisId=0;

	window.setInterval(function(){
		$('#body').removeClass(dataArray[thisId]);
		thisId++;
		if (thisId==3){
			thisId=0;
		}
		
		$('#body').addClass(dataArray[thisId]);
		
	},8000);        
});

function check(email){
	
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  
  if(!re.test(email)){
	  
	  alert("this is not a valid email");
	  
  }

}

function forgot(type,email){
	
	var xmlhttp = new XMLHttpRequest();
	
	xmlhttp.open('GET','reset.php?type='+type+'&email='+email,true);
	
	xmlhttp.send();
	
	xmlhttp.onreadystatechange = function(){
		
		if(xmlhttp.readyState !=4 && xmlhttp.status == 200){
			
			alert("your password was sent to your email");
			window.location = "index.php";
			
		}
		
	}
	
}

</script>

</head>

<body id="body" class="myWebBody body1">
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<ul class="user-menu nav-links">
					<li class="pull-right nav-link">
						<a href="create.php">Create New Account</a>
					</li>
				</ul>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
	
				
<div class="container myContainer">
	<div class="row padd-top mySEC">
		<div class="col-md-6 no-pad">
			<a class="navbar-brand main-link" href="./">Al geleses For Online CarRenting</a>
		</div>
		<div class="col-md-6 no-pad">
		</div>
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default newPanel">
				<div class="panel-heading newPanelHeading">Login</div>
				
				<?php 
				
					if(isset($_POST['submit'])){
						
						$type = $_POST['type'];
						
						if($type == 1){
							
							$rem = false;
						
							if(isset($_POST['remember'])){
								
								$rem = true;
								
							}
							
							$user = addslashes($_POST['email']);
							$pass = addslashes($_POST['password']);
							
							if($admin->login($user,$pass,$rem)){
								
								header('location: admin/');
								
							}else{
								
								$click = "forgot('admin','".$user."')";
								
							echo '<div class="alert bg-danger" role="alert">
									<svg class="glyph stroked cancel">
									<use xlink:href="#stroked-cancel"></use></svg>
									user not found
									<a href="#" onClick="'.$click.'"> forgot your password? </a>
								</div>';

								
							}
							
						}
						
						if($type == 2){
							
							$rem = false;
						
							if(isset($_POST['remember'])){
								
								$rem = true;
								
							}
							
							$user = addslashes($_POST['email']);
							$pass = addslashes($_POST['password']);
							
							
							if($customer->login($user,$pass,$rem)){

								header('location: customer/');

							}else{

								$click = "forgot('customer','".$user."')";
								
								echo '<div class="alert bg-danger" role="alert">
										<svg class="glyph stroked cancel">
										<use xlink:href="#stroked-cancel"></use></svg>
											user not found
											<a href="#" onClick="'.$click.'"> forgot your password? </a>
									</div>';

							}
							
						}
						
						if($type == 3){
							
							$rem = false;
							
							if(isset($_POST['remember'])){
								
								$rem = true;
								
							}
							
							$user = addslashes($_POST['email']);
							$pass = addslashes($_POST['password']);
							if($emplo->login($user,$pass,$rem)){

								header('location: employee/');

							}else{

								$click = "forgot('employee','".$user."')";
								

							echo '<div class="alert bg-danger" role="alert">
									<svg class="glyph stroked cancel">
									<use xlink:href="#stroked-cancel"></use></svg>
										user not found
										<a href="#" onClick="'.$click.'"> forgot your password? </a>
								</div>';


							}
							
						}
						
					}
				
				?>
				
				<div class="panel-body">
					<form role="form" method="post">
						<fieldset>
							<div class="form-group">
								<select class="form-control" name="type">
									<option value="1" selected>Admin</option>
									<option value="2">Customer</option>
									<option value="3">Employee</option>
								</select>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="E-mail" onChange="check(this.value)" name="email" type="email">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Password" name="password" type="password" value="">
							</div>
							<div class="form-group checkbox">
								<label>
									<input name="remember" type="checkbox" value="Remember Me">Remember Me
								</label>
							</div>
							<div class="form-group">
								<button type="submit" name="submit" class="btn btn-primary">Login</button>
							</div>
						</fieldset>
					</form>
				</div>
			</div>
		</div>
		
	</div>
</div>
<!-- <script src="assets/js/jquery-1.11.1.min.js"></script> -->
<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/chart.min.js"></script>
	<script src="assets/js/chart-data.js"></script>
	<script src="assets/js/easypiechart.js"></script>
	<script src="assets/js/easypiechart-data.js"></script>
	<script src="assets/js/bootstrap-datepicker.js"></script> <script>
		!function ($) {
			$(document).on("click","ul.nav li.parent > a > span.icon", function(){		  
				$(this).find('em:first').toggleClass("glyphicon-minus");	  
			}); 
			$(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
