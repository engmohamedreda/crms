<?php 

	ob_start();
	require_once('../includes.php');
	
	$employee = new employee();
	
	if(!$employee->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $employee->data();
	
	if(!$employee->get($id)){
		
		header('location: ../');
		
	}
	
	$data  = $employee->data();
	
	$employee->logout();
	
	header('location: ../');
	
					
?>

