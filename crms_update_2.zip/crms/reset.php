<?php 

require_once('includes.php');

if(isset($_GET['type']) && isset($_GET['email'])){
	
	$type = $_GET['type'];
	$email = $_GET['email'];
	
	switch($type){
		
		case "admin":
		
			$admin = new admin();
		
			$admin->getAdmin(null);
		
			$data = $admin->data();
		
			$emailx = null;
			$namex  = null;
			$passx  = null;

			if(is_array($data)){
				
				foreach($data as $d){
					
					if($d['email'] == $email){
						
						$emailx = $d['email'];
						$namex  = $d['name'];
						$passx  = $d['pass'];
							
						$mailto = new mailto();
						
						if(!$mailto->send($emailx,$namex,"Password Reset E-Mail","password : ".$passx)){
							
							echo $mailto->message();
							
						}else{
							
							echo 'ok';
							
						}
						
						break;
						
					}
					
				}
				
			}
			
			break;
		
		case "employee":
		
			$employee = new employee();
			
			$employee->get(null);
			
			$data = $employee->data();
		
			$emailx = null;
			$namex  = null;
			$passx  = null;

			if(is_array($data)){
				
				foreach($data as $d){
					
					if($d['email'] == $email){
						
						$emailx = $d['email'];
						$namex  = $d['name'];
						$passx  = $d['pass'];
							
						$mailto = new mailto();
						
						if(!$mailto->send($emailx,$namex,"Password Reset E-Mail","password : ".$passx)){
							
							echo $mailto->message();
							
						}
						
						break;
						
					}
					
				}
				
			}
			
			break;
		
		case "customer":
		
			$customer = new customer();
		
			$customer->get(null);
		
			$data = $customer->data();
		
			$emailx = null;
			$namex  = null;
			$passx  = null;

			if(is_array($data)){
				
				foreach($data as $d){
					
					if($d['email'] == $email){
						
						$emailx = $d['email'];
						$namex  = $d['fname'];
						$passx  = $d['pass'];
							
						$mailto = new mailto();
						
						if(!$mailto->send($emailx,$namex,"Password Reset E-Mail","password : ".$passx)){
							
							echo $mailto->message();
							
						}
						
						break;
						
					}
					
				}
				
			}
			
			break;
		
	}
	
}