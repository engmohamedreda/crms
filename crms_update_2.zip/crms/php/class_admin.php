<?php

// class admin

class admin{
	
	private $message = null;
	private $data    = null;
	
	private $access  = null;
	
	public function __construct(){
		
		require_once('class_db_query.php');
		require_once('class_access.php');
		
		$this->access = new access();
		
	}
	
	public function add($name,$email,$pass,$passConfirm){
		
		if(empty($name) || empty($email) || empty($pass) || empty($passConfirm)){
			
			$this->message = "please fill all fields";
			
			return false;
			
		}
		
		if($pass != $passConfirm){
			
			$this->message = "password not match";
			
			return false;
			
		}
		
		if(strlen($pass) < 6){
			
			$this->message = "weak password";
			
			return false;
			
		}
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		db_query::select('admin',null,"admin_email = '{$email}'");
		
		if(db_query::counter() != 0){
			
			$this->message = "email is already in use";
			
			return false;
			
		}
		
		$insert = db_query::insert('admin',"admin_name,admin_email,admin_password","'{$name}','{$email}','{$pass}'");
		
		if(!$insert){
			
			$this->message = "error while saving data";
			
			return false;
			
		}
		
		return true;
		
	}
	
	public function edit($name,$email,$pass,$passConfirm,$id){
		
		if(empty($name) || empty($email)){
			
			$this->message = "please fill all fields";
			
			return false;
			
		}
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		$plus_ = null;
		
		if($pass != null){
			
			if($pass != $passConfirm){
				
				$this->message = "password not match";
				
				return false;
				
			}
			
			$plus_ = ", admin_password = '{$pass}'";
			
		}
		
		db_query::select('admin',null,"admin_email = '{$email}' and admin_id <> '{$id}'");
		
		if(db_query::counter() != 0){
			
			$this->message = "email is already in use";
			
			return false;
			
		}
		
		$update = db_query::update('admin',"admin_name = '{$name}' , admin_email = '{$email}'".$plus_,"admin_id = '{$id}'");
		
		if(!$update){
			
			$this->message = "error while updating data";
			
			return false;
			
		}
		
		return true;
		
	} 
	
	public function getAdmin($id){
		
		if($id == null){
			
			$select = db_query::select('admin',null,null);
			
		}else{
			
			$select = db_query::select('admin',null,"admin_id = '{$id}'");
		
		}
		
		if(!$select){
			
			$this->message = "error while fetching data";
			
			return false;
			
		}
		
		if(db_query::counter() == 0){
			
			$this->message = "no data";
			
			return false;
			
		}
		
		$data   = array();
		$results = db_query::results();
		
		foreach($results as $result){
			
			if($result['admin_id'] != 1001){
			
				array_push($data,array('id' => $result['admin_id'],'name' => $result['admin_name']
				,'email' => $result['admin_email'],'pass' => $result['admin_password']));
			
			}
			
		}
		
		$this->data = null;
		
		$this->data = $data;
		
		return true;
		
	}
	
	public function remove($id){
		
		db_query::update('employee',"admin_id = 1001","admin_id = '{$id}'");
		
		$delete = db_query::delete('admin',"admin_id = '{$id}'");
		
		if($delete){
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function login($email,$password,$rem){
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		$select = db_query::select('admin',null,"admin_email = '{$email}'");
		
		if(db_query::counter() != 1){
			
			return false;
			
		}
		
		$pass = null;
		$id   = null;
		
		$results = db_query::results();
		
		foreach($results as $result){
			
			$id   = $result['admin_id'];
			
			$pass = $result['admin_password'];
			
		}
		
		if($id == 1001){
			
			return false;
			
		}
		
		if($pass == $password){
			
			if($rem){
				
				$this->access->setLongAccess('admin',$id);
				
			}else{
				
				$this->access->setShortAccess('admin',$id);
				
			}
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function isLog(){
		
		if($this->access->checkAccess('admin')){
			
			$this->data = $this->access->key();
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function logout(){
		
		$this->access->removeAccess('admin');
		
	}
	
	public function data(){
		
		return $this->data;
		
	}
	
	public function message(){
		
		return $this->message;
		
	}
	
}