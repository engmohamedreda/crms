<?php 

if(!isset($_GET['userId'])){
	
	return;
	
}

require_once('android@classess/classCars.php');

require_once('android@classess/classUser.php');

$user = new user();

if($user->isSave($_GET['userId']) != true){
	
	return;
	
}

$car_id = 0;

if(isset($_GET['car'])){
	
	$car_id = $_GET['car'];
	
}

$search = null;

if(isset($_GET['search']) && !empty($_GET['search'])){
	
	$search = $_GET['search'];
	
}

$cars = new cars();

$jsonArray = $cars->getCars($car_id,$search);

if(!is_array($jsonArray)){
	
	$jsonArray = array();
	
}

echo json_encode($jsonArray);