<?php

// class db_query

class db_query{
	
	private static $counter = 0;
	private static $results = null;
	private static $error   = null;
	private static $con     = null;
	private static $last_id = 0;
	
	private static function getConnected(){
		
		// host name
		$host = 'localhost';

		// host username
		$user = 'root';

		//host password
		$pass = '';

		//database name
		$db = 'crms_db';

		self::$con = new mysqli($host,$user,$pass,$db);
		
		if(self::$con->connect_errno){
			
			exit();
			
			return false;
			
		}
		
		return true;
		
	}
	
	public static function insert($table,$cols,$values){
		
		self::getConnected();
		
		$sql = "insert into ".$table."(".$cols.") values(".$values.")";
		
		if(self::$con->query($sql)){
			
			self::$last_id = self::$con->insert_id;
			
			self::$con->close();
			
			return true;
			
		}
		
		self::$error = self::$con->error;
		
		self::$con->close();
		
		return false;
		
	}
	
	public static function update($table,$updates,$where){
		
		self::getConnected();
		
		$sql = "update ".$table." set ".$updates." where ".$where;
		
		if(self::$con->query($sql)){
			
			self::$con->close();
			
			return true;
			
		}
		
		self::$error = self::$con->error;
		
		self::$con->close();
		
		return false;
		
	}
	
	public static function select($table,$cols,$where){
		
		self::getConnected();
		
		if($cols == null){
			
			$cols = "*";
			
		}
		
		if($where == null){
			
			$NWhere = null;
			
		}else{
			
			$NWhere = " where ".$where;
			
		}
		
		self::$counter = 0;
		self::$results = null;
		
		$sql   = "select ".$cols." from ".$table.$NWhere;
		
		$query = self::$con->query($sql);
		
		if($query){
			
			self::$counter = 0;
			
			self::$counter = $query->num_rows;
			
			if(self::$counter != 0){
				
				$data = array();
				
				while($row = $query->fetch_array()){
					
					array_push($data,$row);
				
				}
				
				self::$results = $data;
				
			}
			
			self::$con->close();
			
			return true;
			
		}
		
		$query = null;
		
		self::$con->close();
		
		return false;
		
	}
	
	public static function delete($table,$where){
		
		$con = self::getConnected();
		
		if($where == null){
			
			$where = null;
			
		}else{
			
			$where = " where ".$where;
			
		}
		
		$sql   = "delete from ".$table.$where;
		
		if(self::$con->query($sql)){
			
			self::$con->close();
			
			return true;
			
		}
		
		self::$error = self::$con->error;
		
		self::$con->close();
		
		return false;
		
	}
	
	public static function last_id(){
		
		return self::$last_id;
		
	}
	
	public static function counter(){
		
		return self::$counter;
		
	}
	
	public static function error(){
		
		return self::$error;
		
	}
	
	public static function results(){
		
		return self::$results;
		
	}
	
}