<?php 

	ob_start();
	require_once('../includes.php');
	
	$admin = new admin();
	
	if(!$admin->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $admin->data();
	
	if(!$admin->getAdmin($id)){
		
		header('location: ../');
		
	}
	
	$data  = $admin->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['name'];
		$email = $singleData['email'];
		$id    = $singleData['id'];
	
	}
	
	$admin->logout();
	
	header('location: ../');
	
					
?>

