<?php 

if(!isset($_GET['userId']) || !isset($_GET['car']) || !isset($_GET['start']) || !isset($_GET['end'])){
	
	return;
	
}

require_once('android@classess/classUser.php');

$user = new user();

$statue = $user->book($_GET['userId'],$_GET['car'],$_GET['start'],$_GET['end']);

$jsonArray = array();

if($statue != true){
	
	$jsonArray['false']  = $user->message();
	
}else{
	
	$jsonArray['true']  = "1";
	
}

echo json_encode($jsonArray);