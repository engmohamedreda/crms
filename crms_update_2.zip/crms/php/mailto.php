<?php

class mailto{
	
	private $message = null;
	
	public function send($to,$toname,$subject,$body){
				
		require_once('PHPMailer-master/PHPMailerAutoload.php');
		
		$mail = new PHPMailer;

		$frommail = "saudicrms@gmail.com";
		$fromname = "Al geleses For Online CarRenting";
		
		$mail->isSMTP();                       
		$mail->Host = 'smtp.gmail.com';
		$mail->SMTPAuth = true;
		$mail->Username = 'saudicrms@gmail.com';
		$mail->Password = 'carrentsystem';
		$mail->SMTPSecure = 'ssl';
		$mail->Port = 465;

		$mail->setFrom($frommail, $fromname);
		$mail->addAddress($to, $toname);     

		$mail->isHTML(true);                                

		$mail->Subject = $subject;
		$mail->Body    = $body;

		if(!$mail->send()){
			
			$this->message = $mail->ErrorInfo;
			
			return false;
			
		}else{
			
			return true;
			
		}
			
	}
	
	public function message(){
		
		return $this->message;
		
	}
	
}