<?php 

require_once('classConfig.php');

class connect extends config{
	
	private $message = null; 
	protected $con   = null;
	
	public function start(){
	
		$utf8Encode = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
		
		$host = self::host();
		$db   = self::db();
		$name = self::user();
		$pass = self::pass();
		
		try{
			
			$this->con = new PDO('mysql:host='.$host.';dbname='.$db,$name,$pass,$utf8Encode);
			$this->con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			
		}catch(PDOException $ex){
			
			$this->message = "Connection Error : ".$ex->getMessage();
			
		}
		
		return $this;
		
	}
	
	public function error(){
	
		return $this->error;
		
	}
	
}