<?php 

	ob_start();
	require_once('../includes.php');
	
	$employee = new employee();
	
	if(!$employee->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $employee->data();
	
	if(!$employee->get($id)){
		
		header('location: ../');
		
	}
	
	$data  = $employee->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['name'];
		$email = $singleData['email'];
		$phone = $singleData['phone'];
		$id    = $singleData['id'];
	
	}
	
	if(!isset($_GET['id'])){
		
		header('location: ./cars.php');
		
	}
	
	$carId = $_GET['id'];
					
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $name ?></title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/datepicker3.css" rel="stylesheet">
<link href="../assets/css/styles.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="../assets/css/fa.css" rel="stylesheet">

<!--Icons-->
<script src="../assets/js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="../assets/js/html5shiv.js"></script>
<script src="../assets/js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<?php 
	
		include_once('parts/header.php');
		
		$car = new car();
		
		if(!$car->get($carId)){
			
			header('location: ./cars.php');
			
		}
		
		$data = $car->data();
		
		foreach($data as $d){
		
			$carName  = $d['name'];
			$carBrand = $d['brand'];
			$carProce = $d['proce'];
			$carModel = $d['model'];
			$carColor = $d['color'];
			$return = $d['return'];
			$carLice  = $d['lice'];
			$carId    = $d['id'];
			$status   = $d['status'];
			$quantity = $d['quant'];
			$img = $d['img'];
			
		}
		
	?>
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="./"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class=""><a href="./cars.php">cars</a></li>
				<li class="active">edit Car</li>
			</ol>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">edit Car</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="col-md-10">
					<?php 
						if(isset($_POST['submit'])){
							
							$name = $_POST['name'];
							$brand = $_POST['brand'];
							$proce = $_POST['proce'];
							$model = $_POST['model'];
							$return = $_POST['return'];
							$color = $_POST['color'];
							$quantity = $_POST['quantity'];
							$status = $_POST['status'];
							$licDate = $_POST['licDate'];
							$img = $_FILES['img'];
							
							if($car->edit($name,$brand,$proce,$model,$color,$licDate,$return,$quantity,$status,$img,$carId)){
								echo'<div class="alert bg-success" role="alert">
										<svg class="glyph stroked checkmark">
											<use xlink:href="#stroked-checkmark"></use>
										</svg>
										car data updated
									</div>';
									
									if(!$car->get($carId)){
			
										header('location: ./cars.php');
										
									}
									
									$data = $car->data();
									
									foreach($data as $d){
																
										$carName  = $d['name'];
										$carBrand = $d['brand'];
										$carProce = $d['proce'];
										$carModel = $d['model'];
										$carColor = $d['color'];
										$return = $d['return'];
										$carLice  = $d['lice'];
										$carId    = $d['id'];
										$status   = $d['status'];
										$quantity = $d['quant'];
										$img = $d['img'];
										
									}
									
							}else{
								echo'<div class="alert bg-danger" role="alert">
										'.$car->message().'
									</div>';
							}
							
						}
					?>
					<form role="form" method="post" enctype="multipart/form-data">
						
						<div class="form-group">
							<label>Car name</label>
							<input class="form-control" name="name" value="<?= $carName ?>">
						</div>
						<div class="form-group">
							<label>Car brand</label>
							<input class="form-control" name="brand" value="<?= $carBrand ?>">
						</div>
						<div class="form-group">
							<label>Car proce</label>
							<input class="form-control" name="proce" value="<?= $carProce ?>">
						</div>
						<div class="form-group">
							<label>Car model</label>
							<input class="form-control" name="model" value="<?= $carModel ?>">
						</div>
						<div class="form-group">
							<label>Car color</label>
							<input class="form-control" name="color" value="<?= $carColor ?>">
						</div>
						<div class="form-group">
							<label>Return car</label>
							<input class="form-control" name="return" value="<?= $return ?>">
						</div>
						<div class="form-group">
							<label>seats quantity</label>
							<input class="form-control" name="quantity" value="<?= $quantity ?>">
						</div>
						<div class="form-group">
							<label>photo</label>
							<input type="file" name="img">
							<img src="../carsImages/<?= $img ?>" width="100" />
						</div>
						<div class="form-group">
							<label>Car status</label>
							<select name="status" class="form-control">
								<option>choose car status</option>
								<option value="0" selected>available</option>
								<option value="1">not available</option>
							</select>
						</div>
						<div class="form-group">
							<label>Car license expiry date</label>
							<input id="calendar" class="form-control" name="licDate" value="<?= $carLice ?>">
						</div>
						<div class="form-group">
							<button type="submit" name="submit" class="btn btn-primary">Save</button>
							<button type="reset" class="btn btn-default">Reset</button>
						</div>
						<br><br>
					</form>
				</div>
			</div>
		</div>
		
	</div>

	<script src="../assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/chart.min.js"></script>
	<script src="../assets/js/chart-data.js"></script>
	<script src="../assets/js/easypiechart.js"></script>
	<script src="../assets/js/easypiechart-data.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
			format: "yyyy-mm-dd"
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
