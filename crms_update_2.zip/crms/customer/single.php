<?php 

	ob_start();
	require_once('../includes.php');
	
	$customer = new customer();
	
	if(!$customer->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $customer->data();
	
	if(!$customer->get($id)){
		
		header('location: ../');
		
	}
	
	$data  = $customer->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['fname'];
		$email = $singleData['email'];
		$phone = $singleData['phone'];
		$id    = $singleData['id'];
	
	}
	require_once('../android/android@classess/classCars.php');

	require_once('../android/android@classess/classUser.php');

	$user = new user();

	if($user->isSave($id) != true){
		
		header('location: ../');
		
	}

	$search = null;

	if(isset($_GET['search']) && !empty($_GET['search'])){
		
		$search = $_GET['search'];
		
	}
	
	if(isset($_GET['car'])){
		
		$car_id = $_GET['car'];
		
	}else{
		
		header('location: ./');
		
	}
	
	$cars = new cars();

	$jsonArray = $cars->getCars($car_id,$search);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $name ?></title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/datepicker3.css" rel="stylesheet">
<link href="../assets/css/styles.css" rel="stylesheet">

<!--Icons-->
<script src="../assets/js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<?php 
	
		include_once('parts/header.php');
		
	?>
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="./"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Profile</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Cars List</h1>
			</div>
		</div>
		<div class="row">
		<?php
							
		if(is_array($jsonArray)){
	
			foreach($jsonArray as $data){
				
				if($data['status'] == 0){
				
					$lsd = "available";
					$book = '<a href="book.php?car='.$data['id'].'" class="btn btn-success delbtns">
									Book
								</a>';
					
				}else{
					
					$lsd = "not available";
					$book = '<button class="btn btn-danger delbtns" disabled>
								not available
							</button>';
					
				}
				
				?>
			<div class="col-xs-12 col-md-9 col-lg-9">
				<div class="panel panel-blue panel-widget ">
					<table class="table">
						<thead>
						
							<tr>
								<th class="color-gray xl-font">car name</th>
								<th class="color-gray xl-font"><?= $data['name'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">car brand</th>
								<th class="color-gray xl-font"><?= $data['brand'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">car model</th>
								<th class="color-gray xl-font"><?= $data['model'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">car color</th>
								<th class="color-gray xl-font"><?= $data['color'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">car price</th>
								<th class="color-gray xl-font"><?= $data['price'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">Return car</th>
								<th class="color-gray xl-font"><?= $data['Return_car'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">Seats quantity</th>
								<th class="color-gray xl-font"><?= $data['Seats_quantity'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">car lice exp date</th>
								<th class="color-gray xl-font"><?= $data['lice_exp_date'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">car photo</th>
								<th class="color-gray xl-font"><?= $data['price'] ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">car status</th>
								<th class="color-gray xl-font"><?= $lsd  ?></th>
							</tr>
							<tr>
								<th class="color-gray xl-font">book this car</th>
								<th class="color-gray xl-font"><?= $book  ?></th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<img src="../carsImages/<?= $data['img'] ?>" class="img-responsive">
			</div>
					<?php
					
				}
			
			}
		
			?>
		</div>
		
	</div>

	<script src="../assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/chart.min.js"></script>
	<script src="../assets/js/chart-data.js"></script>
	<script src="../assets/js/easypiechart.js"></script>
	<script src="../assets/js/easypiechart-data.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
