<?php 

	ob_start();
	require_once('../includes.php');
	
	$employee = new employee();
	
	if(!$employee->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $employee->data();
	
	if(!$employee->get($id)){
		
		header('location: ../');
		
	}
	
	$data  = $employee->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['name'];
		$email = $singleData['email'];
		$phone = $singleData['phone'];
		$id    = $singleData['id'];
	
	}
				
	$car = new car();
				
	if(isset($_GET['del_id'])){
		
		$idx = $_GET['del_id'];
	
		if($car->remove($idx)){
			
			header('location: ./cars.php');
			
		}else{
			
			echo $car->message();
			
		}
			
	}
	
					
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $name ?></title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/datepicker3.css" rel="stylesheet">
<link href="../assets/css/styles.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="../assets/css/fa.css" rel="stylesheet">

<!--Icons-->
<script src="../assets/js/lumino.glyphs.js"></script>
<script>

function deleteLink(id){
	
	var confirmation = confirm("Delete Car ?");
	
	if(confirmation){
		
		window.location = "cars.php?del_id="+id;
		
	}
	
}

</script>
<!--[if lt IE 9]>
<script src="../assets/js/html5shiv.js"></script>
<script src="../assets/js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<?php 
	
		include_once('parts/header.php');
		
	?>
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="./"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Cars</li>
			</ol>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Cars</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading" id="userx">Cars</div>
					<div class="panel-body" id="get">
					
						<table class="table table-hover">
						
							<thead>
								<tr>
									<th>car id</th>
									<th>car name</th>
									<th>car brand</th>
									<th>car model</th>
									<th>car color</th>
									<th>car status</th>
									<th>car price</th>
									<th>Return_car</th>
									<th>Seats quantity</th>
									<th>licence expiry date</th>
									<th>car photo</th>
									<th>emp ssn</th>
									<th>edit</th>
									<th>delete</th>
								</tr>
							</thead>
							<tbody>
							
							<?php 
							
								$car = new car();
							
								if($car->get(null)){
									
									$List = $car->data();
									
									foreach($List as $result){
								
									if($result['status'] == 0){
										
										$lsd = "available";
										
									}else{
										
										$lsd = "not available";
										
									}
								
								?>
								
									<tr>
										<td><?= $result['id'] ?></td>
										<td><?= $result['name'] ?></td>
										<td><?= $result['brand'] ?></td>
										<td><?= $result['model'] ?></td>
										<td><?= $result['color'] ?></td>
										<td><?= $lsd ?></td>
										<td><?= $result['proce'] ?></td>
										<td><?= $result['quant'] ?></td>
										<td><?= $result['return'] ?></td>
										<td><?= $result['lice'] ?></td>
										<td><img src="../carsImages/<?= $result['img'] ?>" width="100" /></td>
										<td><?= $result['ssn'] ?></td>
										<td>
											<a href="edit_car.php?id=<?= $result['id'] ?>" class="btn btn-info delbtns">
												<i class="fa fa-pencil-square-o"></i>
											</a>
										</td>
										<td>
											<a onClick="deleteLink(<?= $result['id'] ?>)" class="btn btn-danger delbtns">
												<i class="fa fa-times fa-fw"></i>
											</a>
										</td>
									</tr>
									
								<?php 
										
									}
									
								}else{
									
									echo '<h1> no results </h1>';
									
								}
							?>
							</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</div>

	<script src="../assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/chart.min.js"></script>
	<script src="../assets/js/chart-data.js"></script>
	<script src="../assets/js/easypiechart.js"></script>
	<script src="../assets/js/easypiechart-data.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
