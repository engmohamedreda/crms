<?php

require_once('classQuery.php');
require_once('classConfig.php');
		
class rent{
	
	private $message;
	private $query;
	private $config;
	
	public function __construct(){
		
		$this->query = new query();
		$this->config = new config();
		
	}
	
	public function getRents($id,$customer){
		
		if($id != 0){
			
			$where = array('rent_id' => $id,'cust_id' => $customer);
			
		}else{
			
			$where = array('cust_id' => $customer);;
			
		}
		
		if($id != 0){
			
			$this->query->move('update','rent',array('rent_status' => 1),array('rent_id' => $id),null,null,null);
			
		}
		
		$this->query->move('select','rent',null,$where,null,null,"order by car_id desc");
		
		if($this->query->rowCount() == 0){
			
			return null;
			
		}
		
		$array = array();
		
		$link  = $this->config->link();
		
		$now   = date('Y-m-d');
		
		foreach($this->query->result() as $result){
			
			$id     = $result->rent_id;
			$start_date   = $result->start_date;
			$end_date   = $result->end_date;
			$running_line  = $result->running_line;
			$rent_status  = $result->rent_status;
			$credit_hours  = $result->credit_hours;
			$credit_kilos  = $result->credit_kilos;
			$total_price  = $result->total_price;
			$delay_cost  = $result->delay_cost;
			$car_id  = $result->car_id;
			$status  = $result->rent_status;
			
			
			
			array_push($array, array('id' => $id,'start' => $start_date,'end' => $end_date,
			'running_line' => $running_line,'status' => $status,'car_id' => $car_id,'delay_cost' => $delay_cost,
			'credit_hours' => $credit_hours,'credit_kilos' => $credit_kilos,'total_price' => $total_price));
			
		}
		
		return $array;
		
	}
	
}