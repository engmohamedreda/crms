<?php

class customer{

	private $message = null;
	private $data    = null;
	
	public function __construct(){
		
		require_once('class_db_query.php');
		require_once('class_access.php');
		
		$this->access = new access();
		
	}
	
	public function remove($id){
		
		$delete = db_query::delete('rent',"cust_id = '{$id}'");
		
		if(!$delete){
			
			$this->message = "failed to remove customer please try again";
			
			return false;
			
		}
		
		$delete = db_query::delete('booking',"customer_id = '{$id}'");
		
		if(!$delete){
			
			$this->message = "failed to remove customer please try again";
			
			return false;
			
		}
		
		$delete = db_query::delete('customer',"cust_id = '{$id}'");
		
		if(!$delete){
			
			$this->message = "failed to remove customer please try again";
			
			return false;
			
		}
		
		return true;
		
	}
	
	public function add($fname,$lname,$country,$city,$phone,$email,$age,$sex,$lice_exp,$pass,$passConfirm){
		
		if(empty($fname) || empty($lname) || empty($country) || empty($city) || empty($phone) || empty($email)
			|| empty($age) || empty($sex) || empty($pass) || empty($passConfirm)){
			
			$this->message = "please fill all fields";
			
			return false;
			
		}
		
		if($pass != $passConfirm){
			
			$this->message = "password not match";
			
			return false;
			
		}
		
		if(strlen($pass) < 6){
			
			$this->message = "weak password";
			
			return false;
			
		}
		
		if(!is_numeric($phone)){
		
			$this->message = "this is not a valid phone";
			
			return false;
		
		}
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		db_query::select('customer',null,"cust_email = '{$email}'");
		
		if(db_query::counter() != 0){
			
			$this->message = "email is already in use";
			
			return false;
			
		}
		
		$insert = db_query::insert('customer',
				"`cust_f_name`, `cust_l_name`, `cust_address_country`, `cust_address_city`,`lice_exp_date`,
				`cust_email`, `cust_password`, `cust_sex`, `cust_age`"
				,"'{$fname}','{$lname}','{$country}','{$city}','{$lice_exp}','{$email}','{$pass}','{$sex}','{$age}'");
		
		if(!$insert){
			
			$this->message = "error while saving data : ".db_query::error();
			
			return false;
			
		}
		
		$lastId = db_query::last_id();
		
		$insert = db_query::insert('phone',"`customer_ssn`, `customer_phone`"
				,"'{$lastId}','{$phone}'");
		
		if(!$insert){
			
			$this->message = "error while saving data  : ".db_query::error();
			
			return false;
			
		}
		
		return true;
		
	}

	public function edit($fname,$lname,$email,$password,$confirm,$id){
		
		if(empty($fname) || empty($lname) || empty($email)){
			
			$this->message = "please fill all fields";
			
			return false;
			
		}
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		$plus_ = null;
		
		if($password != null){
			
			if($password != $confirm){
				
				$this->message = "password not match";
				
				return false;
				
			}
			
			$plus_ = ", cust_password = '{$confirm}'";
			
		}
		
		db_query::select('customer',null,"customer_email = '{$email}' and cust_id <> '{$id}'");
		
		if(db_query::counter() != 0){
			
			$this->message = "email is already in use";
			
			return false;
			
		}
		
		$update = db_query::update('customer',"cust_f_name = '{$fname}' , cust_l_name = '{$lname}', cust_email = '{$email}'".$plus_,"cust_id = '{$id}'");
		
		if(!$update){
			
			$this->message = "error while updating data";
			
			return false;
			
		}
		
		return true;
		
	} 
	
	public function logout(){
		
		$this->access->removeAccess('customer');
		
	}
	
	public function get($id){
		
		if($id == null){
			
			$select = db_query::select('customer',null,null);
			
		}else{
			
			$select = db_query::select('customer',null,"cust_id = '{$id}'");
		
		}
		
		if(!$select){
			
			$this->message = "error while fetching data";
			
			return false;
			
		}
		
		if(db_query::counter() == 0){
			
			$this->message = "no data";
			
			return false;
			
		}
		
		$data   = array();
		$results = db_query::results();
		
		foreach($results as $result){
			
			db_query::select('phone',null,"customer_ssn = '".$result['cust_id']."'");
			
			$phone = null;
			
			$resq = db_query::results();
			
			if(is_array($resq)){
				
				foreach($resq as $res){
					
					$phone = $res['customer_phone'];
					
				}
				
			}
				
			array_push($data,array('id' => $result['cust_id'],'fname' => $result['cust_f_name'],'lname' => $result['cust_l_name'],'country' => $result['cust_address_country'],
									'city' => $result['cust_address_city'],'lice_exp_date' => $result['lice_exp_date'],'email' => $result['cust_email'],
									'sex' => $result['cust_sex'],'phone' => $phone,'age' => $result['cust_age'],'pass' => $result['cust_password']));
			
		}
		
		$this->data = $data;
		
		return true;
		
	}
	
	public function isLog(){
		
		if($this->access->checkAccess('customer')){
			
			$this->data = $this->access->key();
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function login($email,$password,$rem){
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		$select = db_query::select('customer',null,"cust_email = '{$email}'");
		
		if(db_query::counter() != 1){
			
			return false;
			
		}
		
		$pass = null;
		$id   = null;
		
		$results = db_query::results();
		
		foreach($results as $result){
			
			$id   = $result['cust_id'];
			
			$pass = $result['cust_password'];
			
		}
		
		if($id == 1001){
			
			return false;
			
		}
		
		if($pass == $password){
			
			if($rem){
				
				$this->access->setLongAccess('customer',$id);
				
			}else{
				
				$this->access->setShortAccess('customer',$id);
				
			}
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function message(){
		
		return $this->message;
		
	}
	
	public function data(){
		
		return $this->data;
		
	}
	
}