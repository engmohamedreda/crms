<?php

class booking{

	private $message = null;
	private $data    = null;
	
	public function __construct(){
		
		require_once('class_db_query.php');
	}
	
	public function get($id){
		
		if($id == null){
			
			$select = db_query::select('booking',null,"booking_id > 0 order by booking_status asc");
			
		}else{
			
			$select = db_query::select('booking',null,"booking_id = '{$id}'");
		
		}
		
		if(!$select){
			
			$this->message = "error while fetching data";
			
			return false;
			
		}
		
		if(db_query::counter() == 0){
			
			$this->message = "no data";
			
			return false;
			
		}
		
		$data   = array();
		$results = db_query::results();
		
		foreach($results as $result){
			
			$customer_name = null;
			$car_name = null;
			
			db_query::select('customer',null,"cust_id = '{$result['customer_id']}'");
			
			$res1 = db_query::results();
			
			foreach($res1 as $res){
				
				$customer_name = $res['cust_f_name'];
				
			}
			
			db_query::select('car',null,"car_id = '{$result['car_id']}'");
			
			$res2 = db_query::results();
			
			foreach($res2 as $res){
				
				$car_name = $res['car_name'];
				
			}
			
			array_push($data,array('id' => $result['booking_id'],'start' => $result['booking_start_date'],
									'end' => $result['booking_end_date'],'status' => $result['booking_status'],
									'customer_id' => $result['customer_id'],'customer_name' => $customer_name
									,'car' => $result['car_id'],'car_name' => $car_name));
			
		}
		
		$this->data = $data;
		
		return true;
		
	}
	
	public function setRent($booking_id,$delay_cost,$running_line,$credit_hours,$credit_kilos,$total_price,$payment,$emp){
		
		$select = db_query::select('booking',null,"booking_id = '{$booking_id}'");
		
		if(!$select){
			
			$this->message = "check booking number";
			
			return false;
			
		}
		
		$start = null;
		$end   = null;
		$cust_id = null;
		$car_id = null;
		
		if(preg_match('/[^a-zA-Z]/', $running_line)){
			
			$this->message = "running line must contains only characters";
			
			return false;
			
		}
		
		if(preg_match('/[^a-zA-Z]/', $payment)){
			
			$this->message = "payment must contains only characters";
			
			return false;
			
		}
		
		$results = db_query::results();
		
		foreach($results as $result){
				
			$start = $result['booking_start_date'];
			$end   = $result['booking_end_date'];
			$cust_id = $result['customer_id'];
			$car_id = $result['car_id'];
			
		}
		
		$cols = "`start_date`, `end_date`, `delay_cost`, `running_line`, `rent_status`, `credit_hours`,
		`credit_kilos`, `total_price`, `payment`, `emp_id`, `cust_id`, `car_id`, `booking_id`";
		
		$values = "'{$start}','{$end}','{$delay_cost}','{$running_line}','0',
					'{$credit_hours}','{$credit_kilos}','{$total_price}','{$payment}',
					'{$emp}','{$cust_id}','{$car_id}','{$booking_id}'";
		
		$select = db_query::insert('rent',$cols,$values);
		
		if(!$select){
			
			$this->message = "cannot save rent values";
			
			return false;
			
		}
		
		db_query::update('booking','booking_status = 1',"booking_id = '{$booking_id}'");
		
		return true;
		
	}
	public function getRents($id){
		
		if($id == null){
			
			$select = db_query::select('rent',null,null);
			
		}else{
			
			$select = db_query::select('rent',null,"rent_id = '{$id}'");
		
		}
		
		if(!$select){
			
			$this->message = "error while fetching data";
			
			return false;
			
		}
		
		if(db_query::counter() == 0){
			
			$this->message = "no data";
			
			return false;
			
		}
		
		$data   = array();
		$results = db_query::results();
		
		foreach($results as $result){
			
			$customer_name = null;
			$car_name = null;
			
			db_query::select('customer',null,"cust_id = '{$result['cust_id']}'");
			
			$res1 = db_query::results();
			
			foreach($res1 as $res){
				
				$customer_name = $res['cust_f_name'];
				
			}
			
			db_query::select('car',null,"car_id = '{$result['car_id']}'");
			
			$res2 = db_query::results();
			
			foreach($res2 as $res){
				
				$car_name = $res['car_name'];
				
			}
			
			array_push($data,array('id' => $result['rent_id'],'start' => $result['start_date'],
									'end' => $result['end_date'],'status' => $result['rent_status'],
									'payment' => $result['payment'], 'running_line' => $result['running_line'],
									'delay_cost' => $result['delay_cost'],'credit_hours' => $result['credit_hours'],
									'credit_kilos' => $result['credit_kilos'],'total_price' => $result['total_price'],
									'customer_name' => $customer_name,'car' => $result['car_id'],'car_name' => $car_name));
			
		}
		
		$this->data = $data;
		
		return true;
		
	}
	
	public function remove($id){
		
		db_query::delete('rent',"booking_id = '{$id}'");
		
		$delete = db_query::delete('booking',"booking_id = '{$id}'");
		
		if($delete){
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function removeRent($id){
		
		$delete = db_query::delete('rent',"rent_id = '{$id}'");
		
		if($delete){
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function message(){
		
		return $this->message;
		
	}
	
	public function data(){
		
		return $this->data;
		
	}
	
}