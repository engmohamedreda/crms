<?php 

	ob_start();
	require_once('includes.php');
	
	$customer = new customer();

	$fname = addslashes($_POST['fname']);
	$lname = addslashes($_POST['lname']);
	$country = addslashes($_POST['country']);
	$city = addslashes($_POST['city']);
	$phone = addslashes($_POST['phone']);
	$email = addslashes($_POST['email']);
	$age = addslashes($_POST['age']);
	$sex = addslashes($_POST['sex']);
	$exp = addslashes($_POST['licence_exp']);
	$pass = addslashes($_POST['pass']);
	$passConfirm = addslashes($_POST['passConfirm']);
	
	if($customer->add($fname,$lname,$country,$city,$phone,$email,$age,$sex,$exp,$pass,$passConfirm)){
		
		echo'<div class="alert bg-success" role="alert">
				<svg class="glyph stroked checkmark">
					<use xlink:href="#stroked-checkmark"></use>
				</svg>
				 account created successfully
			</div>';
			echo'<script>
			
				redirect();
			
			</script>
			';
		
	}else{
		
	echo '<div class="alert bg-danger" role="alert">
				<svg class="glyph stroked cancel">
				<use xlink:href="#stroked-cancel"></use></svg>
					'.$customer->message().'
			</div>';
	}
	

?>
