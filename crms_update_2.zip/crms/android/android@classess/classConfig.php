<?php

class config{
	
	private $host     = 'localhost';
	private $database = 'crms_db';
	private $hostUser = 'root';
	private $hostPass = '';	
	private $link     = '';	
	
	protected function host(){
	
		return $this->host;
		
	}
	
	protected function db(){
	
		return $this->database;
		
	}
	
	protected function user(){
	
		return $this->hostUser;	
		
	}
	
	protected function pass(){
	
		return $this->hostPass;	
		
	}
	
	public function link(){
	
		return $this->link;	
		
	}
	
}