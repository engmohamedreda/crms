<?php

require_once('classQuery.php');
require_once('classConfig.php');
		
class cars{
	
	private $message;
	private $query;
	private $config;
	
	public function __construct(){
		
		$this->query = new query();
		$this->config = new config();
		
	}
	
	public function getCars($id,$search){
		
		$key = null;
		
		if($id != 0){
			
			$where = array('car_id' => $id);
			
		}else{
			
			if($search != null){
				
				$where = array('car_name' => '%'.$search.'%');
				
				$key = array('like');
				
			}else{
				
				$where = null;
				
			}
			
		}
		
		$this->query->move('select','car',null,$where,$key,null,"order by car_id desc");
		
		if($this->query->rowCount() == 0){
			
			return null;
			
		}
		
		$array = array();
		
		$link  = $this->config->link();
		
		$now   = date('Y-m-d');
		
		foreach($this->query->result() as $result){
			
			$id     = $result->car_id;
			$name   = $result->car_name;
			$model  = $result->car_model;
			$color  = null;
			$brand  = $result->car_brand;
			$price  = $result->car_price;
			$Return_car  = $result->Return_car;
			$Seats_quantity  = $result->Seats_quantity;
			$img  = $result->photo;
			$lice_exp_date  = $result->lice_exp_date;
			$status = 0;
			
			$this->query->move('select','color',null,array('car_id' => $id),null,null,null);
			
			foreach($this->query->result() as $book_result){
				
				$color  = $book_result->car_color;
				
			}
			
			if($id != 0){
				
				$this->query->move('select','rent',null,array('car_id' => $id),null,null,null);
				
				if($this->query->rowCount() == 0){
					
					$status = 0;
					
				}else{
					
					foreach($this->query->result() as $book_result){
						
						$startDate = $book_result->start_date;
						$endDate   = $book_result->end_date;
						
						if($now >= $startDate && $now <= $endDate){
							
							$status = 1;
							
						}
						
					}
					
				}
				
			}
			
			array_push($array, array('id' => $id,'price' => $price,'name' => $name,
						'color' => $color,'model' => $model,'brand' => $brand,
						'status' => $status,'Return_car' => $Return_car,'img' => $img
						,'Seats_quantity' => $Seats_quantity,'lice_exp_date' => $lice_exp_date));
			
		}
		
		return $array;
		
	}
	
}