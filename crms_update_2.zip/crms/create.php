<?php 

	ob_start();
	require_once('includes.php');
	
	$admin = new admin();
	$emplo = new employee();
	$customer = new customer();
	
	if($admin->isLog()){
		
		$data = $admin->data();
		
		if($admin->getAdmin($data)){
			
			header('location: admin/');
			
		}else{
			
			$admin->logout();
			
		}
		
	}
	
	if($emplo->isLog()){
		
		$data = $emplo->data();
		
		if($emplo->get($data)){
			
			header('location: employee/');
			
		}else{
			
			$emplo->logout();
			
		}
		
	}
	
	if($customer->isLog()){
		
		$data = $customer->data();
		
		if($customer->get($data)){
			
			header('location: customer/');
			
		}else{
			
			$customer->logout();
			
		}
		
	}
						
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>create account</title>

<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/datepicker3.css" rel="stylesheet">
<link href="assets/css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="assets/js/html5shiv.js"></script>
<script src="assets/js/respond.min.js"></script>
<![endif]-->
<script src="js/jquery-1.11.3.min.js"></script>
<script>
$(function(){
	var dataArray=new Array();
	dataArray[0]="body1";
	dataArray[1]="body2";
	dataArray[2]="body3";

	var thisId=0;

	window.setInterval(function(){
		$('#body').removeClass(dataArray[thisId]);
		thisId++;
		if (thisId==3){
			thisId=0;
		}
		
		$('#body').addClass(dataArray[thisId]);
		
	},8000);        
});
$(document).ready(function(){
	
	$("#send").click(function(){
		
		document.getElementById("send").disabled = true;
		document.getElementById("send").innerHTML = "please wait...";
		
		$.ajax({
			
			 type: "POST",
			 url: "form.php",
			 data: $('form#reg-form').serialize(),
			 
			 success: function(msg){
				 
				document.getElementById("message-status").innerHTML = msg;
				
				$('html, body').animate({ scrollTop: 0 }, 'fast');
				document.getElementById("send").disabled = false;
				document.getElementById("send").innerHTML = "SEND";
				
			 },error: function(){
				 
				$('html, body').animate({ scrollTop: 0 }, 'fast');
				document.getElementById("send").disabled = false;
				document.getElementById("send").innerHTML = "SEND";
	
				document.getElementById("message-status").innerHTML = "Error! Please Check Your Internet Connection.";
				
			 }
		 
	   });
	   
	});
	
});

function redirect(){
	
	$(document).ready(function() {
		window.setTimeout(function(){window.location.href = "./"},1000);
	});

}

</script>
<script>

	function checke(email){
	
	  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	  
	  if(!re.test(email)){
		  
		  alert("this is not a valid email");
		  
	  }

	}

	function checkc(city){
	
	  if(!isNaN(city)){
		  
		  alert("please select a valid city");  
		  return false;  
		  
	  }
	  
	  if(city == "other"){
		  
		  $("#input").load('city.php?getText=yes');
		  
	  }

	}

	function checkp(phone){
	 
		if(isNaN(phone) || phone.length != 10) { 
			alert("this is not a valid phone");  
			return false;  
        } 
		
	}

</script>
</head>

<body id="body" class="myWebBody body1">
	
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="./">Al geleses For Online CarRenting</a>
				<ul class="user-menu">
					<li class="pull-right">
						<a href="index.php">login</a>
					</li>
				</ul>
			</div>
							
		</div><!-- /.container-fluid -->
	</nav>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading">create account</div>
				<div id="message-status"></div>
				<div class="panel-body">
					<form role="form" method="post" name="form" id="reg-form">
						<fieldset>
							<div class="form-group">
								<input class="form-control" placeholder="first name" name="fname" type="text" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="last name" name="lname" type="text" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="country" name="country" type="text" autofocus="">
							</div>
							<div class="form-group" id="input">
								<select name="city" onChange="checkc(this.value)" class="form-control">
									<option value="0">city</option>
									<option value="Abhā">Abhā</option>
									<option value="Abqaiq">Abqaiq</option>
									<option value="Al-Baḥah">Al-Baḥah</option>
									<option value="Al-Dammām">Al-Dammām</option>
									<option value="Al-Hufūf">Al-Hufūf</option>
									<option value="Al-Jawf">Al-Jawf</option>
									<option value="Al-Kharj (oasis)">Al-Kharj (oasis)</option>
									<option value="Al-Khubar">Al-Khubar</option>
									<option value="Al-Qaṭīf">Al-Qaṭīf</option>
									<option value="Al-Ṭaʾif">Al-Ṭaʾif</option>
									<option value="ʿArʿar">ʿArʿar</option>
									<option value="Buraydah">Buraydah</option>
									<option value="Dhahran">Dhahran</option>
									<option value="Ḥāʾil">Ḥāʾil</option>
									<option value="Jiddah">Jiddah</option>
									<option value="Jīzān">Jīzān</option>
									<option value="Khamīs Mushayt">Khamīs Mushayt</option>
									<option value="King Khalīd Military City">King Khalīd Military City</option>
									<option value="Mecca">Mecca</option>
									<option value="Medina">Medina</option>
									<option value="Najrān">Najrān</option>
									<option value="Ras Tanura">Ras Tanura</option>
									<option value="Riyadh">Riyadh</option>
									<option value="Sakākā">Sakākā</option>
									<option value="Tabūk">Tabūk</option>
									<option value="Yanbuʿ">Yanbuʿ</option>
									<option value="other">other</option>
								</select>
							</div>
							<div class="form-group">
								<input class="form-control" onChange="checkp(this.value)" placeholder="phone" name="phone" type="text" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="age" name="age" type="text" autofocus="">
							</div>
							<div class="form-group">
								<select name="sex" class="form-control">
									<option value="">gender</option>
									<option value="male">male</option>
									<option value="female">female</option>
								</select>
							</div>
							<div class="form-group">
								<input id="calendar" class="form-control" placeholder="licence expiry date" name="licence_exp" type="text" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" onChange="checke(this.value)" placeholder="E-mail" name="email" type="email" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Password" name="pass" type="password" value="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Confirm Password" name="passConfirm" type="password" value="">
							</div>
							<input type="button" name="submit" id="send" class="btn btn-primary" value="create account"/>
						</fieldset>
					</form>
				</div>
			</div>
		</div>
	</div>	
	
		

	<script src="assets/js/jquery-1.11.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/chart.min.js"></script>
	<script src="assets/js/chart-data.js"></script>
	<script src="assets/js/easypiechart.js"></script>
	<script src="assets/js/easypiechart-data.js"></script>
	<script src="assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
			format: "yyyy-mm-dd"
		});

		!function ($) {
			$(document).on("click","ul.nav li.parent > a > span.icon", function(){		  
				$(this).find('em:first').toggleClass("glyphicon-minus");	  
			}); 
			$(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
