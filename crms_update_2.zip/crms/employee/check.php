<?php 

	ob_start();
	require_once('../includes.php');
	
	$employee = new employee();
	
	if(!$employee->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $employee->data();
	
	if(!$employee->get($id)){
		
		header('location: ../');
		
	}
	
	$data  = $employee->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['name'];
		$email = $singleData['email'];
		$phone = $singleData['phone'];
		$id    = $singleData['id'];
	
	}
	
	if(!isset($_GET['id'])){
		
		header('location: ./bookings.php');
		
	}
	
	$carId = $_GET['id'];
					
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $name ?></title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/datepicker3.css" rel="stylesheet">
<link href="../assets/css/styles.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="../assets/css/fa.css" rel="stylesheet">

<!--Icons-->
<script src="../assets/js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="../assets/js/html5shiv.js"></script>
<script src="../assets/js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<?php 
	
		include_once('parts/header.php');
		
		$booking = new booking();
		
		if(!$booking->get($carId)){
			
			header('location: ./bookings.php');
			
		}
		
	?>
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="./"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class=""><a href="./bookings.php">bookings</a></li>
				<li class="active">set rent</li>
			</ol>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">set rent</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="col-md-10">
					<?php 
						if(isset($_POST['submit'])){
							
							$delay_cost = $_POST['delay_cost'];
							$running_line = $_POST['running_line'];
							$credit_hours = $_POST['credit_hours'];
							$credit_kilos = $_POST['credit_kilos'];
							$total_price = $_POST['total_price'];
							$payment = $_POST['payment'];
							
							if($booking->setRent($carId,$delay_cost,$running_line,$credit_hours,$credit_kilos,$total_price,$payment,$id)){
								echo'<div class="alert bg-success" role="alert">
										<svg class="glyph stroked checkmark">
											<use xlink:href="#stroked-checkmark"></use>
										</svg>
										successful rent
									</div>';
									
									
							}else{
								echo'<div class="alert bg-danger" role="alert">
										'.$booking->message().'
									</div>';
							}
							
						}
					?>
					<form role="form" method="post" enctype="multipart/form-data">
						`
						<div class="form-group">
							<label>rent delay cost</label>
							<input class="form-control" name="delay_cost" type="number">
						</div>
						<div class="form-group">
							<label>rent running line</label>
							<input class="form-control" name="running_line">
						</div>
						<div class="form-group">
							<label>rent credit hours</label>
							<input class="form-control" name="credit_hours" type="number">
						</div>
						<div class="form-group">
							<label>rent credit kilos</label>
							<input class="form-control" name="credit_kilos" type="number">
						</div>
						<div class="form-group">
							<label>rent total price</label>
							<input class="form-control" name="total_price" type="number">
						</div>
						<div class="form-group">
							<label>rent payment</label>
							<input class="form-control" name="payment" type="text">
						</div>
						<div class="form-group">
							<button type="submit" name="submit" class="btn btn-primary">Save</button>
							<button type="reset" class="btn btn-default">Reset</button>
						</div>
						<br><br>
					</form>
				</div>
			</div>
		</div>
		
	</div>

	<script src="../assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/chart.min.js"></script>
	<script src="../assets/js/chart-data.js"></script>
	<script src="../assets/js/easypiechart.js"></script>
	<script src="../assets/js/easypiechart-data.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
			format: "yyyy-mm-dd"
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
