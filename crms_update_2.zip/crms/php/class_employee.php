<?php

// class employee

class employee{
	
	private $message = null;
	private $data    = null;
	
	private $access  = null;
	
	public function __construct(){
		
		require_once('class_db_query.php');
		require_once('class_access.php');
		
		$this->access = new access();
		
	}
	
	public function add($ssn,$name,$email,$phone,$pass,$passConfirm,$admin){
		
		if(empty($name) || empty($email) || empty($pass) || empty($phone) || empty($admin) || empty($passConfirm)){
			
			$this->message = "please fill all fields";
			
			return false;
			
		}
		
		if(!is_numeric($ssn) || strlen($ssn) != 5){
			
			$this->message = "employee ssn must be a number and length = 5";
			
			return false;
			
		}
		
		if($pass != $passConfirm){
			
			$this->message = "password not match";
			
			return false;
			
		}
		
		if(strlen($pass) < 6){
			
			$this->message = "weak password";
			
			return false;
			
		}
		
		if(!is_numeric($phone) || strlen($phone) != 10){
		
			$this->message = "this is not a valid phone";
			
			return false;
		
		}
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		db_query::select('employee',null,"emp_email = '{$email}'");
		
		if(db_query::counter() != 0){
			
			$this->message = "email is already in use";
			
			return false;
			
		}
		
		db_query::select('employee',null,"emp_ssn = '{$ssn}'");
		
		if(db_query::counter() != 0){
			
			$this->message = "ssn is already in use choose another one";
			
			return false;
			
		}
		
		$insert = db_query::insert('employee',"`emp_ssn`, `emp_name`, `emp_email`, `emp_phone`, `emp_password`, `admin_id`"
											 ,"'{$ssn}','{$name}','{$email}','{$phone}','{$pass}','{$admin}'");
		
		if(!$insert){
			
			$this->message = "error while saving data";
			
			return false;
			
		}
		
		return true;
		
	}
	
	public function edit($name,$email,$phone,$pass,$passConfirm,$id){
		
		if(empty($name) || empty($email) || empty($phone)){
			
			$this->message = "please fill all fields";
			
			return false;
			
		}
		
		if(!is_numeric($phone) || strlen($phone) != 10){
		
			$this->message = "this is not a valid phone";
			
			return false;
		
		}
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		$plus_ = null;
		
		if($pass != null){
			
			if($pass != $passConfirm){
				
				$this->message = "password not match";
				
				return false;
				
			}
			
			$plus_ = ", emp_password = '{$pass}'";
			
		}
		
		db_query::select('employee',null,"emp_email = '{$email}' and emp_ssn <> '{$id}'");
		
		if(db_query::counter() != 0){
			
			$this->message = "email is already in use";
			
			return false;
			
		}
		
		$update = db_query::update('employee',"emp_ssn = '{$id}' ,emp_name = '{$name}' , emp_email = '{$email}', emp_phone = '{$phone}'".$plus_,"emp_ssn = '{$id}'");
		
		if(!$update){
			
			$this->message = "error while updating data";
			
			return false;
			
		}
		
		return true;
		
	} 
	
	public function get($id){
		
		if($id == null){
			
			$select = db_query::select('employee',null,null);
			
		}else{
			
			$select = db_query::select('employee',null,"emp_ssn = '{$id}'");
		
		}
		
		if(!$select){
			
			$this->message = "error while fetching data";
			
			return false;
			
		}
		
		if(db_query::counter() == 0){
			
			$this->message = "no data";
			
			return false;
			
		}
		
		$data   = array();
		$results = db_query::results();
		
		foreach($results as $result){
			
			if($result['emp_ssn'] != 1001){
			
				array_push($data,array('id' => $result['emp_ssn'],'name' => $result['emp_name'],
				'email' => $result['emp_email'],'phone' => $result['emp_phone'],'admin' => $result['admin_id'],'pass' => $result['emp_password']));
			
			}
			
		}
		
		$this->data = $data;
		
		return true;
		
	}
	
	public function remove($id){
		
		db_query::update('car',"emp_id = 1001","emp_id = '{$id}'");
		db_query::update('rent',"emp_id = 1001","emp_id = '{$id}'");
		
		$delete = db_query::delete('employee',"emp_ssn = '{$id}'");
		
		if($delete){
			
			return true;
			
		}
		
		$this->message = db_query::error();
		
		return false;
		
	}
	
	public function login($email,$password,$rem){
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$this->message = "this is not a valid email";
			
			return false;
		
		}
		
		$select = db_query::select('employee',null,"emp_email = '{$email}'");
		
		if(db_query::counter() != 1){
			
			return false;
			
		}
		
		$pass = null;
		$id   = null;
		
		$results = db_query::results();
		
		foreach($results as $result){
			
			$id   = $result['emp_ssn'];
			
			$pass = $result['emp_password'];
			
		}
		
		if($id == 1001){
			
			return false;
			
		}
		
		if($pass == $password){
			
			if($rem){
				
				$this->access->setLongAccess('employee',$id);
				
			}else{
				
				$this->access->setShortAccess('employee',$id);
				
			}
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function isLog(){
		
		if($this->access->checkAccess('employee')){
			
			$this->data = $this->access->key();
			
			return true;
			
		}
		
		return false;
		
	}
	
	public function logout(){
		
		$this->access->removeAccess('employee');
		
	}
	
	public function data(){
		
		return $this->data;
		
	}
	
	public function message(){
		
		return $this->message;
		
	}
	
}