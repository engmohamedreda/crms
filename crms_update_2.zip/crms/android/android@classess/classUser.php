<?php

require_once('classQuery.php');
		
class user{
	
	private $message;
	private $id , $name;
	private $query;
	
	public function __construct(){
		
		$this->query = new query();
		
	}
	
	public function login($email,$password){
		
		$this->query->move('select','customer',null,array('cust_email' => $email,'cust_password' => $password),null,'and',null);

		if($this->query->rowCount() != 1){
			
			return false;
			
		}
		
		foreach($this->query->result() as $result){
			
			$this->id   = $result->cust_id;
			$this->name = $result->cust_f_name;
			
		}
		
		return true;
		
	}
	
	public function isSave($id){
		
		$this->query->move('select','customer',null,array('cust_id' => $id),null,null,null);

		if($this->query->rowCount() != 1){
			
			return false;
			
		}
		
		return true;
		
	}
	
	public function book($user,$car,$start,$end){
		
		$thisDate = date('Y-m-d');
		
		$dateStart    = new DateTime($start);
		$newStartDate = $dateStart->format('Y-m-d');
		
		$dateEnd    = new DateTime($end);
		$newEndDate = $dateEnd->format('Y-m-d');
		
		if($dateStart > $dateEnd){
			
			$this->message = "start date cannot after end date";
			return false;
			
		}
		
		if(strtotime($start) < strtotime($thisDate)){
			
			$this->message = "start date cannot after current date";
			return false;
			
		}
		
		$this->query->move('select','booking',null,array('car_id' => $car),null,null,null);
		
		if($this->query->rowCount() != 0){
			
			foreach($this->query->result() as $result){
				
				$startDate = $result->booking_start_date;
				$endDate   = $result->booking_end_date;
				
				if($newStartDate >= $startDate && $newStartDate <= $endDate){
					
					$this->message = "please choose another date";
					return false;
					
				}
				
				if($newEndDate >= $startDate && $newEndDate <= $endDate){
					
					$this->message = "please choose another date";
					return false;
					
				}
				
				
			}
			
		}
		
		$dataArray = array('booking_start_date' => $start,'booking_end_date' => $end,
							'booking_status' => 0,'customer_id' => $user,'car_id' => $car);
		
		$this->query->move('insert','booking',$dataArray,null,null,null,null);
		
		if($this->query->error() != null){
			
			$this->message = $this->query->error();
			return false;
			
		}else{
			
			return true;
			
		}
		
	}
	
	public function message(){
		
		return $this->message;
		
	}
	
	public function id(){
		
		return $this->id;
		
	}
	
	public function name(){
		
		return $this->name;
		
	}
	
}