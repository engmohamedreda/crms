<?php 

if(!isset($_GET['userId'])){
	
	return;
	
}

require_once('android@classess/classRent.php');

require_once('android@classess/classUser.php');

$user = new user();

if($user->isSave($_GET['userId']) != true){
	
	return;
	
}

$car_id = 0;

if(isset($_GET['rent'])){
	
	$car_id = $_GET['rent'];
	
}

$rent = new rent();

$jsonArray = $rent->getRents($car_id);

echo json_encode($jsonArray);