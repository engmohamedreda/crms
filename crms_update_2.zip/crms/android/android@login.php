<?php 

if(!isset($_GET['appEmail']) || !isset($_GET['appPass'])){
	
	return;
	
}

require_once('android@classess/classUser.php');

$user = new user();

$statue = $user->login($_GET['appEmail'],$_GET['appPass']);

$jsonArray = array();

if($statue != true){
	
	$jsonArray['false']  = "0";
	
}else{
	
	$jsonArray['true']  = $user->id();
	
}

echo json_encode($jsonArray);