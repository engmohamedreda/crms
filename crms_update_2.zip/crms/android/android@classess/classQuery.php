<?php

require_once('classConnect.php');
		
class query extends connect{
	
	private $error    = null;
	private $result   = null;
	private $rowCount = 0;
	private $lastId   = 0;
	
	public function move($case,$table,$values = array(),$where = array(),$another,$bind,$limitCodes){
		
		switch($case){
		
			case 'insert':
				self::insert($table,$values,$another);
				break;

			case 'update':
				self::update($table,$values,$where,$bind,$another);
				break;
				
			case 'select':
				self::select($table,$where,$limitCodes,$bind,$another);
				break;	
				
			case 'delete':
				self::delete($table,$where,$limitCodes,$bind);
				break;
			
			case 'destroy':
				self::delete($table);
				break;
							
		}
	}
	
	private function insert($table,$values = array(),$isBlob){
		
		$arrayCount = count($values);
		
		if($arrayCount == 0){
			
			$this->error = 'array count 0';
			
			return $this;
			
		}
		
		$parameters = '';
		
		for($x = 1 ; $x <= $arrayCount ; $x++){
			
			$parameters = $parameters.'?';
			
			if($x < $arrayCount){
				
				$parameters = $parameters.',';
				
			}
			
		}
		
		$names = array_keys($values);
		
		$sql = 'insert into `'.$table.'`('.implode(',',$names).') values('.$parameters.')';
		
		self::start();
		
		$statment = $this->con->prepare($sql);
		
		$z = 1;
		
		foreach($values as $value){
			
			if($z == $isBlob){
			
				$fopen = fopen($value, 'rb');
				
				if(file_exists($value)){
					
					$statment->bindParam($z , $fopen , PDO::PARAM_LOB);

				}else{
					
					$statment->bindParam($z , null);
					
				}
				
				$z++;
				
			}else{
			
				$statment->bindvalue($z , $value);
				$z++;
			}
			
		}
		
		if(!$statment->execute()){
				
			$this->error = $statment->error;
			
			$statment = null;
			$con = null;
			
			return $this;
				
		}
		
		$this->lastId = $this->con->lastInsertId();
		
		$statment = null;
		$con = null;
		return $this ;
		
	}
	
	private function update($table,$values = array(),$where = array(),$bind,$isBlob){
		
		$arrayCount = count($values);
		$whereCount = count($where);
		
		if($arrayCount == 0){
			
			$this->error = 'array count 0';
			
			return $this;
			
		}
		
		$cond = null;
		
		if($whereCount != 0){
			
			$cond = " where ";
			
			$rnames = array_keys($where);
			
			$r = 0;
			
			for($c = 1 ; $c <= $whereCount ; $c++){
				
				$cond = $cond.$rnames[$r].' = ?';
				
				if($c < $whereCount){
					
					$cond = $cond.' '. $bind . ' ';
					
				}
				
				$r++;
				
			}
		
		}
		
		$names = array_keys($values);
		
		$set = null;
		
		$n = 0;
		
		for($c = 1 ; $c <= $arrayCount ; $c++){
			
			$set = $set.$names[$n].' = ?';
			
			if($c < $arrayCount){
				
				$set = $set.' ,';
				
			}
			
			$n++;
			
		}
		
		$sql = 'update ' . $table . ' set '. $set . " " . $cond;
		
		self::start();
		
		$statment = $this->con->prepare($sql);
		
		$z = 1;
		
		foreach($values as $value){
			
			if($z == $isBlob){
			
				$fopen = fopen($value, 'rb');
				
				if(file_exists($value)){
					
					$statment->bindParam($z , $fopen , PDO::PARAM_LOB);

				}else{
					
					$statment->bindParam($z , null);
					
				}
				
				$z++;
				
			}else{
			
				$statment->bindvalue($z , $value);
				$z++;
			}
			
		}
		
		if($whereCount != 0){
			
			foreach($where as $value){
				
				$statment->bindvalue($z , $value);
				$z++;
				
			}
			
		}
		
		if(!$statment->execute()){
				
			$this->error = $statment->error;
			
			$statment = null;
			$con = null;
			
			return $this;
				
		}
		
		$statment = null;
		$con = null;
		return $this ;
		
	}
	
	private function select($table,$where = array(),$limitCodes,$bind,$another){
		
		$arrayCount = count($where);
		
		$cond = null;
		
		if($arrayCount > 0){
			
			$cond = " where ";
			
			$rnames = array_keys($where);
			
			$r = 0;
			
			for($c = 1 ; $c <= $arrayCount ; $c++){
				
				if(is_array($another) && $another != 0 && $another != null){
				
					$cond = $cond . $rnames[$r] . ' '.$another[$r].' ?';
				
				}else{
					
					$cond = $cond . $rnames[$r] . ' = ?';
					
				}
				
				if($c < $arrayCount){
					
					if(is_array($bind)){
						
						$cond = $cond .' '. $bind[$r] . ' ';
						
					}else{
						
						$cond = $cond .' '. $bind . ' ';
						
					}
					
						
				}
				
				$r++;
				
			}
			
		}
		
		$sql = "select * from ".$table.$cond." ".$limitCodes;

		self::start();
		
		$statment = $this->con->prepare($sql);
		
		$z = 1;
		
		if($arrayCount > 0){
			
			foreach($where as $value){
				
				$statment->bindvalue($z , $value);
				$z++;
				
			}
			
		}
		
		if($statment->execute()){
			
			$this->result   = $statment->fetchALL(pdo::FETCH_OBJ);
			$this->rowCount = $statment->rowCount();
			
		}else{
			
			$this->error = $statment->error;
			
		}
		
		return $this;
		
	}
	
	private function delete($table,$where = array(),$limitCodes,$bind){
		
		$arrayCount = count($where);
		
		$cond = null;
		
		if($arrayCount != 0){
			
			$cond = " where ";
			
			$rnames = array_keys($where);
			
			$r = 0;
			
			for($c = 1 ; $c <= $arrayCount ; $c++){
				
				$cond = $cond . $rnames[$r] . ' = ?';
				
				if($c < $arrayCount){
					
					$cond = $cond .' '. $bind . ' ';
					
				}
				
				$r++;
				
			}
			
		}
		
		$sql = "delete from ".$table.$cond." ".$limitCodes;
		
		self::start();
		
		$statment = $this->con->prepare($sql);
		
		$z = 1;
		
		if($arrayCount != 0){
			
			foreach($where as $value){
				
				$statment->bindvalue($z , $value);
				$z++;
				
			}
			
		}
		
		if(!$statment->execute()){
			
			$this->error = $statment->error;
			
			$statment = null;
			$con = null;
			
			return $this;
			
		}
		
		return $this;
		
	}
	
	private function destroy($table){
		
		$sql = "truncate ".$table;
		
		self::start();
		
		$statment = $this->con->prepare($sql);
		
		if(!$statment->execute()){
			
			$this->error = $statment->error;
			
			$statment = null;
			$con = null;
			
			return $this;
			
		}
		
		return $this;
		
	}
	
	public function error(){
	
		return $this->error;	
		
	}
	
	public function result(){
	
		return $this->result;	
		
	}
	
	public function rowCount(){
	
		return $this->rowCount;	
		
	}
	
	public function lastId(){
	
		return $this->lastId;	
		
	}
	
}