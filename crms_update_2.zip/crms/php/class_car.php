<?php

class car{

	private $message = null;
	private $data    = null;
	
	public function __construct(){
		
		require_once('class_db_query.php');
		
	}
	
	public function add($name,$brand,$proce,$model,$color,$licDate,$return,$quant,$status,$emp,$img){
		
		if(empty($name) || empty($brand) || empty($proce) || empty($model) ||
			empty($color) || empty($return) || empty($quant) || empty($licDate) 
			|| empty($emp)){
			
			$this->message = "please fill all fields";
			
			return false;
			
		}
		
		if($status != 0 && $status != 1){
			
			$this->message = "please choose status";
			
			return false;
			
			
		}
		
		if(!is_array($img)){
			
			$this->message = "please add image";
			
			return false;
			
		}
		
		if($status != 1 && $status != 0){
			
			$this->message = "please choose car status";
			
			return false;
			
		}
		
		if(!is_numeric($quant)){
			
			$this->message = "Seats quantity must be a number";
			
			return false;
			
		}
		
		if(!filter_var($proce, FILTER_VALIDATE_FLOAT)){
			
			$this->message = "price must be a float";
			
			return false;
			
		}
		
		$root   = "c:xampp/htdocs/crms/carsImages/";
		
		$filetmp  = $img['tmp_name'];
		$filename = $img['name'];
		
		$exec = pathinfo($filename, PATHINFO_EXTENSION);
		
		$location = $root;
		
		if(!file_exists($root)){
			
			$this->message = "photo location is not exists";
			return false;
			
		}
	
		$oldN = uniqid().uniqid();
		
		$namex = $oldN.'.'.$exec;
		
		$location = $location.'/'.$namex;
		
		if(file_exists($location)){
		
			$this->error = "file is already exists";
			return false;
			
		}
	
		if(!move_uploaded_file($filetmp,$location)){
			
			$this->error = "failed to move uploaded file";
			return false;
			
		}
		
		$cols   = "`car_name`, `car_brand`, `car_price`, `car_model` ,
					`Return_car`, `Seats_quantity`, `car_status`, `lice_exp_date`, `photo`, `emp_id`";
		
		$values = "'{$name}','{$brand}','{$proce}','{$model}','{$return}','{$quant}','{$status}','{$licDate}','{$namex}','{$emp}'";
		
		$insert = db_query::insert('car',$cols,$values);
		
		if(!$insert){
			
			$this->message = "failed to save car data please try again";
			
			return false;
			
		}
		
		$lastId = db_query::last_id();
		
		$insert = db_query::insert('color','`car_id`,`car_color`',"'{$lastId}','{$color}'");
		
		if(!$insert){
			
			$this->message = "failed to save car color please try again";
			
			return false;
			
		}
		
		return true;
		
	}
	
	public function remove($id){
		
		$select = db_query::select('car',null,"car_id = '{$id}'");
		
		$result = db_query::results();
		
		$img = null;
		
		foreach($result as $res){
			
			$img = $res['photo'];
			
		}
		
		$root   = "c:xampp/htdocs/crms/carsImages/".$img;
		
		unlink($root);
		
		$delete = db_query::delete('rent',"car_id = '{$id}'");
		
		if(!$delete){
			
			$this->message = "failed to remove car please try again";
			
			return false;
			
		}
		
		$delete = db_query::delete('booking',"car_id = '{$id}'");
		
		if(!$delete){
			
			$this->message = "failed to remove car please try again";
			
			return false;
			
		}
		
		$delete = db_query::delete('car',"car_id = '{$id}'");
		
		if(!$delete){
			
			$this->message = "failed to remove car please try again";
			
			return false;
			
		}
		
		return true;
		
	}
	
	public function edit($name,$brand,$proce,$model,$color,$licDate,$return,$quant,$status,$img,$id){
		
		if(empty($name) || empty($brand) || empty($proce) || empty($model) ||
			empty($color) || empty($licDate) || empty($id)){
			
			$this->message = "please fill all fields";
			
			return false;
			
		}
		
		if(!empty($img['tmp_name'])){
			
			$root   = "c:xampp/htdocs/crms/carsImages/";
			
			$filetmp  = $img['tmp_name'];
			$filename = $img['name'];
			
			$exec = pathinfo($filename, PATHINFO_EXTENSION);
			
			$location = $root;
			
			if(!file_exists($root)){
				
				$this->message = "photo location is not exists";
				return false;
				
			}
		
			$oldN = uniqid().uniqid();
			
			$namex = $oldN.'.'.$exec;
			
			$location = $location.'/'.$namex;
			
			if(file_exists($location)){
			
				$this->error = "file is already exists";
				return false;
				
			}
		
			if(!move_uploaded_file($filetmp,$location)){
				
				$this->error = "failed to move uploaded file";
				return false;
				
			}
					
			$cols   = "`photo` = '{$namex}'";
			
			$values = "`car_id` = {$id}";
			
			$update = db_query::update('car',$cols,$values);
			
		}
		
		$cols   = "`car_name` = '{$name}', `car_brand` = '{$brand}', `car_price` = '{$proce}'
					, `car_model` = '{$model}' , `Return_car` = '{$return}' ,`Seats_quantity` = '{$quant}', `car_status` = '{$status}'
					, `lice_exp_date` = '{$licDate}'";
		
		$values = "`car_id` = {$id}";
		
		$update = db_query::update('car',$cols,$values);
		
		if(!$update){
			
			$this->message = "failed to update car data please try again";
			
			return false;
			
		}
		
		$cols   = "`car_color` = '{$color}'";
		
		$values = "`car_id` = {$id}";
		
		$update = db_query::update('color',$cols,$values);
		
		if(!$update){
			
			$this->message = "failed to update car color please try again";
			
			return false;
			
		}
		
		return true;
		
	}
	
	public function get($id){
		
		if($id == null){
			
			$select = db_query::select('car',null,null);
			
		}else{
			
			$select = db_query::select('car',null,"car_id = '{$id}'");
		
		}
		
		if(!$select){
			
			$this->message = "error while fetching data";
			
			return false;
			
		}
		
		if(db_query::counter() == 0){
			
			$this->message = "no data";
			
			return false;
			
		}
		
		$data   = array();
		$results = db_query::results();
		
		foreach($results as $result){
			
			db_query::select('color',null,"car_id = '".$result['car_id']."'");
			
			$color = null;
			
			$resq = db_query::results();
			
			foreach($resq as $res){
				
				$color = $res['car_color'];
				
			}
			
			array_push($data,array('id' => $result['car_id'],'name' => $result['car_name'],'brand' => $result['car_brand'],
									'proce' => $result['car_price'],'model' => $result['car_model'],'color' => $color,
									'return' => $result['Return_car'],'quant' => $result['Seats_quantity'],
									'status' => $result['car_status'],'lice' => $result['lice_exp_date'],
									'img' => $result['photo'],'ssn' => $result['emp_id']));
			
		}
		
		$this->data = $data;
		
		return true;
		
	}
	
	public function message(){
		
		return $this->message;
		
	}
	
	public function data(){
		
		return $this->data;
		
	}
	
}