<?php

system::start();

// class system

class system{
	
	public static function start(){
		
		require_once('class_db_query.php');
		
		db_query::select('admin','admin_id',"admin_id = '1001'");
		
		if(db_query::counter() != 1){
		
			if(db_query::counter() == 0){
				
				db_query::insert('admin','admin_id,admin_name,admin_email,admin_password',"1001,'system','system','system'");
				
			}
			
			if(db_query::counter() > 0){
				
				db_query::delete('admin',"admin_id = '1001'");
				
				db_query::insert('admin','admin_id,admin_name,admin_email,admin_password',"1001,'system','system','system'");
				
			}
			
		}
		
		db_query::select('employee','emp_ssn',"emp_ssn = '1001'");
		
		if(db_query::counter() != 1){
		
			if(db_query::counter() == 0){
				
				db_query::insert('employee','emp_ssn,emp_name,emp_email,emp_phone,emp_password,admin_id',
				"1001,'system','system','system','system','1001'");
				
			}
			
			if(db_query::counter() > 0){
				
				db_query::delete('employee',"admin_id = '1001'");
				
				db_query::insert('employee','admin_id,admin_name,admin_email,admin_password',"1001,'system','system','system'");
				
			}
			
		}
		
	}
	
}