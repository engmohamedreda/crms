<?php 

	ob_start();
	require_once('../includes.php');
	
	$customer = new customer();
	
	if(!$customer->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $customer->data();
	
	if(!$customer->get($id)){
		
		header('location: ../');
		
	}
	
	$data  = $customer->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['fname'];
		$email = $singleData['email'];
		$phone = $singleData['phone'];
		$id    = $singleData['id'];
	
	}
	
	if(isset($_GET['car'])){
		
		$car_id = $_GET['car'];
		
	}else{
		
		header('location: ./');
		
	}
	
	require_once('../android/android@classess/classUser.php');

	$user = new user();

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $name ?></title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/datepicker3.css" rel="stylesheet">
<link href="../assets/css/styles.css" rel="stylesheet">

<!--Icons-->
<script src="../assets/js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<?php 
	
		include_once('parts/header.php');
		
	?>
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="./"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Profile</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Cars List</h1>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="col-md-10">
					<?php 
						if(isset($_POST['submit'])){
							
							$statue = $user->book($id,$_GET['car'],$_POST['start'],$_POST['end']);

							if($statue){
								
								echo'<div class="alert bg-success" role="alert">
										<svg class="glyph stroked checkmark">
											<use xlink:href="#stroked-checkmark"></use>
										</svg>
										successful booking
									</div>';
							}else{
								
								echo'<div class="alert bg-danger" role="alert">
										'.$user->message().'
									</div>';
							}
							
						}
					?>
					<form role="form" method="post" enctype="multipart/form-data">
						
						<div class="form-group">
							<label>start date</label>
							<input id="calendar1" class="form-control" name="start">
						</div>
						<div class="form-group">
							<label>end date</label>
							<input id="calendar" class="form-control" name="end">
						</div>
						
						<div class="form-group">
							<button type="submit" name="submit" class="btn btn-primary">Book</button>
							<button type="reset" class="btn btn-default">Reset</button>
						</div>
						<br><br>
					</form>
				</div>
			</div>
		</div>
		
	</div>

	<script src="../assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/chart.min.js"></script>
	<script src="../assets/js/chart-data.js"></script>
	<script src="../assets/js/easypiechart.js"></script>
	<script src="../assets/js/easypiechart-data.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
			format: "yyyy-mm-dd"
		});
		$('#calendar1').datepicker({
			format: "yyyy-mm-dd"
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
