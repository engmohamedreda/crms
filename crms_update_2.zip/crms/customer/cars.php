<?php 

	ob_start();
	require_once('../includes.php');
	
	$customer = new customer();
	
	if(!$customer->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $customer->data();
	
	if(!$customer->get($id)){
		
		header('location: ../');
		
	}
	
	$data  = $customer->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['fname'];
		$email = $singleData['email'];
		$phone = $singleData['phone'];
		$id    = $singleData['id'];
	
	}
	require_once('../android/android@classess/classCars.php');

	require_once('../android/android@classess/classUser.php');

	$user = new user();

	if($user->isSave($id) != true){
		
		header('location: ../');
		
	}

	$search = null;

	if(isset($_GET['search']) && !empty($_GET['search'])){
		
		$search = $_GET['search'];
		
	}

	$cars = new cars();

	$jsonArray = $cars->getCars(0,$search);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $name ?></title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/datepicker3.css" rel="stylesheet">
<link href="../assets/css/styles.css" rel="stylesheet">

<!--Icons-->
<script src="../assets/js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<?php 
	
		include_once('parts/header.php');
		
	?>
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="./"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Profile</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Cars List</h1>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-md-12 col-lg-12">
				<div class="panel-heading">
					<div class="row">
						<div class="col-md-8">
							<div class="input-group">
							</div>
						</div>
					</div>
				</div>

				<div class="panel panel-blue panel-widget ">
					<table class="table">
						<thead>
							<tr>
								<th class="color-gray xl-font">car name</th>
								<th class="color-gray xl-font">car brand</th>
								<th class="color-gray xl-font">car Status</th>
								<th class="color-gray xl-font">
									show
								</th>
							</tr>
						</thead>
						<tbody>
							<?php
							
								if(is_array($jsonArray)){
							
									foreach($jsonArray as $data){
										
										if($data['status'] == 0){
										
											$lsd = "available";
											
										}else{
											
											$lsd = "not available";
											
										}
										
										?>
										
											<tr>
												<td class="color-gray xl-font"><?= $data['name'] ?></td>
												<td class="color-gray xl-font"><?= $data['brand'] ?></td>
												<td class="color-gray xl-font"><?= $lsd ?></td>
												<td class="color-gray xl-font">
													<a href="single.php?car=<?= $data['id'] ?>" class="btn btn-success delbtns">
														show
													</a>
												</td>
											</tr>
										
										<?php
										
									}
								
								}
							
							?>
						
						</tbody>
					</table>
				</div>
			</div>
		</div>
		
	</div>

	<script src="../assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/chart.min.js"></script>
	<script src="../assets/js/chart-data.js"></script>
	<script src="../assets/js/easypiechart.js"></script>
	<script src="../assets/js/easypiechart-data.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
