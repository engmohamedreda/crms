<?php 

	ob_start();
	require_once('../includes.php');
	
	$admin = new admin();
	
	if(!$admin->isLog()){
		
		header('location: ../');
		
	}
	
	$id = $admin->data();
	
	if(!$admin->getAdmin($id)){
		
		header('location: ../');
		
	}
	
	$data  = $admin->data();
	
	foreach($data as $singleData){
		
		$name  = $singleData['name'];
		$email = $singleData['email'];
		$id    = $singleData['id'];
	
	}
			
	$booking = new booking();
				
	if(isset($_GET['del_id'])){
		
		$idx = $_GET['del_id'];
	
		if($booking->removeRent($idx)){
			
			header('location: ./rents.php');
			
		}else{
			
			echo $booking->message();
			
		}
			
	}
	
					
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $name ?></title>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/datepicker3.css" rel="stylesheet">
<link href="../assets/css/styles.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="../assets/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="../assets/css/fa.css" rel="stylesheet">

<!--Icons-->
<script src="../assets/js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="../assets/js/html5shiv.js"></script>
<script src="../assets/js/respond.min.js"></script>
<![endif]-->

<script>

function deleteLink(id){
	
	var confirmation = confirm("Delete Rent ?");
	
	if(confirmation){
		
		window.location = "rents.php?del_id="+id;
		
	}
	
}

</script>

</head>

<body>
	
	<?php 
	
		include_once('parts/header.php');
		
	?>
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="./"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Rents</li>
			</ol>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Rents</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading" id="userx">Rents</div>
					<div class="panel-body" id="get">
					
						<table class="table table-hover">
							<thead>
								<tr>
									<th>ID</th>
									<th>start date</th>
									<th>end date</th>
									<th>customer name</th>
									<th>car id</th>
									<th>status</th>
									<th>payment</th>
									<th>credit hours</th>
									<th>credit kilos</th>
									<th>Running line</th>
									<th>Delay cost</th>
									<th>total price</th>
								</tr>
							</thead>
							<tbody>
							
							<?php 
							
								$booking = new booking();
							
								if($booking->getRents(null)){
									
									$List = $booking->data();
									
									foreach($List as $result){
									
									if($result['status'] != 0){
										
										$check = "seen";
										
									}else{
										
										$check = "not seen";
										
									}
								
								?>
								
									<tr>
										<td><?= $result['id'] ?></td>
										<td><?= $result['start'] ?></td>
										<td><?= $result['end'] ?></td>
										<td><?= $result['customer_name'] ?></td>
										<td><?= $result['car'] ?></td>
										<td><?= $check ?></td>
										<td><?= $result['payment'] ?></td>
										<td><?= $result['credit_hours'] ?></td>
										<td><?= $result['credit_kilos'] ?></td>
										<td><?= $result['running_line'] ?></td>
										<td><?= $result['delay_cost'] ?></td>
										<td><?= $result['total_price'] ?></td>
									</tr>
									
								<?php 
										
									}
									
								}else{
									
									echo '<h1> no results </h1>';
									
								}
							?>
							</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</div>

	<script src="../assets/js/jquery-1.11.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/chart.min.js"></script>
	<script src="../assets/js/chart-data.js"></script>
	<script src="../assets/js/easypiechart.js"></script>
	<script src="../assets/js/easypiechart-data.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
