<?php 

	if(isset($_GET['getText'])){
		
		echo '<input class="form-control" onChange="checkc(this.value)" placeholder="enter your city name" name="city" type="text" autofocus="">';
		
	}


?>
