<?php

// class set_access

class access{
	
	private $oneYear = ( ( (365.25 * 24) * 60 ) * 60 );
	private $oneHour = (60 * 60);
	
	private $key = null;
	
	public function setLongAccess($key,$reference){
		
		// set access for one year
		
		setcookie($key,$reference,time() + $this->oneYear,'/');
		
	}
	
	public function setShortAccess($key,$reference){
		
		// set access for one hour
		
		setcookie($key,$reference,time() + $this->oneHour,'/');
		
	}
	
	public function checkAccess($key){
		
		if(isset($_COOKIE[$key])){
			
			$this->key = $_COOKIE[$key];
			
			return true;
				
		}
		
		return false;
		
	}
	
	public function removeAccess($key){
		
		setcookie($key,null,time() - $this->oneYear,'/');
		
	}

	public function key(){
		
		return $this->key;
		
	}
	
}